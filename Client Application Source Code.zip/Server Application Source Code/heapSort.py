"""
NOTE: this program has been taken from a previous assignment example and is used here as a tool to aid the main program

Alyssa Booth (10496173)
Date: 19/5/2020
Title: Heap Sort Algorithm

Note: The startIndex equation and part of the buildMaxHeap() code was helped by
https://www.geeksforgeeks.org/building-heap-from-array/
"""
def buildMaxHeap(array, index, unsortedArrayLength):
    maxValueIndex = index  # Initialise the current root index as the max value
    leftIndex = 2 * index + 1  # Index of the left Child
    rightIndex = 2 * index + 2  # Index of the right Child

    # If the left child exists and is greater than the root index
    if leftIndex < unsortedArrayLength and array[leftIndex] > array[maxValueIndex]:
        maxValueIndex = leftIndex  # Set the leftIndex as the new max value

    # If the right child exists and is greater than the current maxValueIndex
    if rightIndex < unsortedArrayLength and array[rightIndex] > array[maxValueIndex]:
        maxValueIndex = rightIndex  # Set the rightIndex as the new max value

    # Swap the root to the correct value (if the root index is no longer the max value)
    if index != maxValueIndex:
        array[index], array[maxValueIndex] = array[maxValueIndex], array[index]
        # Call the function again
        buildMaxHeap(array, maxValueIndex, unsortedArrayLength)


def heapSort(array):
    unsortedArrayLength = len(array)  # Initialise the unsorted array to be the full array length
    startIndex = None
    while unsortedArrayLength:
        # Repeat until the unsortedArrayLength becomes 0

        # (1) Build a max heap with the values part of the unsorted array
        # If the max heap is being built for the first time, buildMaxHeap() n/2 times
        # Otherwise, only buildMaxHeap() for the root
        if not startIndex:
            startIndex = int((unsortedArrayLength / 2)) - 1
            # index of the parent of the last node (aka the last non-leaf node)
            for index in range(startIndex, -1, -1):
                buildMaxHeap(array, index, unsortedArrayLength)
        else:
            buildMaxHeap(array, 0, unsortedArrayLength)

        # (2) Swap the first and last nodes within the unsorted array
        array[0], array[unsortedArrayLength - 1] = array[unsortedArrayLength - 1], array[0]

        # (3) Reduce the length of the unsorted array to hide the sorted values at the end of the array
        unsortedArrayLength -= 1

    return array