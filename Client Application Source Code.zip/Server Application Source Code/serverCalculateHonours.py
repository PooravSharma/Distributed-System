import heapSort
class honoursResults:
    def __init__(self):
        self.scores = []
        self.unitScores = {}
        self.HonourResults = {"eligibility": None,
                              "courseAverage": None,
                              "bestScores": None,
                              "averageOfBestScores": None}

    # displaying individual scores on the server in their input order
    def displayScoreInput(self):
        scoreList = ""
        for score in self.scores:
            scoreList = scoreList + str(score) + " "
        print("----------------------------")
        print("   New Honours Request")
        print("----------------------------")
        print(f"Scores: {scoreList}")

    # selecting the best (or highest) 12 marks, and calculating the average of the best 12 marks
    def calculateHighMarks(self):
        sortedScores = heapSort.heapSort(self.scores)
        highest = sortedScores[-12:]
        self.HonourResults["bestScores"] = highest
        self.HonourResults["averageOfBestScores"] = round(sum(highest)/12, 2)

    # calculating the course average
    def calculateCourseAverage(self):
        courseAverage = sum(self.scores)/len(self.scores)
        self.HonourResults["courseAverage"] = round(courseAverage, 2)
        return courseAverage

    # evaluating the qualification according to the Honours evaluation criteria
    def honoursEvaluation(self):
        courseAverage = self.calculateCourseAverage()
        bestAverage = self.HonourResults["averageOfBestScores"]
        result = None
        if courseAverage >= 70:
            result = "QUALIFIED FOR HONOURS STUDY!"
        elif bestAverage >= 80:
            result = "MAY HAVE GOOD CHANCE! Need further assessment!"
        elif bestAverage >= 70:
            result = "MAY HAVE A CHANCE! Must be carefully reassessed and get the coordinator's special permission!"
        else:
            result = "DOES NOT QUALIFY FOR HONOURS STUDY! Try Masters by course work."
        self.HonourResults["eligibility"] = result

    # sending the evaluation result/s back to the client
    def calculateHonoursResults(self, scores, id, unitScores):
        self.scores = scores
        self.unitScores = unitScores
        self.displayScoreInput()
        self.calculateHighMarks()
        self.honoursEvaluation()
        print(f'ID: {id}, '
              f'CAV: {self.HonourResults["courseAverage"]}, '
              f'BAV: {self.HonourResults["averageOfBestScores"]}, '
              f'{self.HonourResults["eligibility"]}')
        return self.HonourResults

