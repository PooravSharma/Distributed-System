import socket
from xmlrpc.server import SimpleXMLRPCServer
import serverCalculateHonours

if __name__ == '__main__':
    with SimpleXMLRPCServer(("0.0.0.0", 8000)) as server:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 1))  # connect() for UDP doesn't send packets
            local_ip = s.getsockname()[0]
            s.close()
        except:
            print("Please ensure that this machine has internet access and relaunch the program")
            input("Press enter to exit")
            exit()
        server.register_instance(serverCalculateHonours.honoursResults(), allow_dotted_names=True)
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        print('Serving XML-RPC on 0.0.0.0 port 8000')
        print("-----------------------------------------")
        print('Please enter the IP below in the client application')
        print("Server IP: "+ local_ip)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nKeyboard interrupt received, exiting.")
            exit(0)