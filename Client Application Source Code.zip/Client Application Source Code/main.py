import menu
import authenticateUser


if __name__ == '__main__':
    print("Please enter the IP shown on the server screen")
    print("OR")
    print("Press Enter to use localhost IF you are running the server on the same machine as the client.")
    ipaddress = input("IP: ")
    newAuthentication = authenticateUser.AuthenticateUser()
    authID = newAuthentication.authenticate()
    while authID != "":
        if ipaddress != "":
            ip = "http://"+ ipaddress+ ":8000/"
            menu.Menu(authID, ip)
        else:
            menu.Menu(authID)
        authID = newAuthentication.authenticate()

