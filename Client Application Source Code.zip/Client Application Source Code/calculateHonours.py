from re import match
from time import sleep
class calculateHonoursClient:
    def __init__(self, proxy, id, useUnitCodes = False):
        self.scores = []
        self.proxy = proxy
        self.id = id
        self.useUnitCodes = useUnitCodes
        self.unitScores = {}
        self.eligibility = "Undetermined"
        self.HonourResults = {"courseAverage": "Not Available",
                              "bestScores": "Note Available",
                              "averageOfBestScores": "Not Available"}
        self.printMenu()
        if useUnitCodes:
            self.inputUnitScores()
        else:
            self.inputScores()
        self.calculationPreProcessing()
        self.calculateHonoursResult()

    def printMenu(self):
        print("==============================")
        print("   Calculate Honours Score")
        print("==============================")
        print("Enter your unit scores for assessment")
        print("Scores must be between 0 and 100")
        print("Please enter 12 to 30 scores")
        print("Press Enter to stop entering scores")

    def inputScores(self):
        while len(self.scores) <30:
            score = input("Enter score: ")
            if score == "":
                if len(self.scores) >= 12:
                    break
                else:
                    print(f"{len(self.scores)} out of minimum 12 enterted, please enter more scores.")
                    continue
            elif score.isnumeric():
                score = int(score)
                if score >= 0 and score <=100:
                    self.scores.append(score)
                else:
                    print("Invalid Score: Score must be between 0 and 100\nScore not added.\n")
            else:
                print("Invalid Score: Score must be a numeric value\nScore not added.\n")

        print(f"\n{len(self.scores)} scores have been added for calculation.\n")
        sleep(3)

    def inputUnitScores(self):
        print("Enter your scores in the following format:")
        print("     unit_code, score")
        print("eg.    CSI3344, 90")

        while len(self.scores) <30:
            unitScore = input("Enter unit and score: ")

            if unitScore == "":
                if len(self.scores) >= 12:
                    break
                else:
                    print(f"{len(self.scores)} out of minimum 12 entered, please enter more unit scores.")
                    continue
            if not match("^.+\\,.+$", unitScore):
                print("Invalid input: Unit score must be in the following format <unit_code, score>\n"
                      "Score not added.\n")
                continue
            splitUnitScore = unitScore.split(",")
            score = splitUnitScore[1].strip()
            unit = splitUnitScore[0]
            if score.isnumeric():
                score = int(score)
                if score >= 0 and score <=100:
                    isValid = self.validateUnitScore(unit, score)
                    if isValid:
                        self.scores.append(score)
                else:
                    print("Invalid Score: Score must be between 0 and 100\nScore not added.\n")
            else:
                print("Invalid Score: Score must be a numeric value\nScore not added.\n")

        print(f"\n{len(self.scores)} unit scores have been added for calculation.\n")
        sleep(3)

    def validateUnitScore(self, unit, score):
        if unit in self.unitScores:
            scoreList = self.unitScores[unit]
            if len(scoreList) == 3:
                print("Invalid input: 3 scores for this unit already exist\nScore not added.\n")
                return False
            elif len(scoreList) == 2:
                if scoreList[0] < 50 and scoreList[1] < 50 and score < 50:
                    print("Invalid input: Unit already has a maximum of two fail grades\nScore not added.\n")
                    return False
                elif (scoreList[0] >= 50 or scoreList[1] >= 50) and score >= 50:
                    print("Invalid input: Unit already has one passing grade\nScore not added.\n")
                    return False
                else:
                    scoreList.append(score)
                    self.unitScores[unit] = scoreList
                    return True
            else:
                if scoreList[0] >= 50 and score >= 50:
                    print("Invalid input: Unit already has one passing grade\nScore not added.\n")
                    return False
                else:
                    scoreList.append(score)
                    self.unitScores[unit] = scoreList
                    return True
        else:
            self.unitScores[unit] = [score]
        return True


    def calculationPreProcessing (self):
        # Determines if a student has more than 5 failed units
        failedUnitCount = 0
        for score in self.scores:
            if score < 50:
                failedUnitCount += 1
            if failedUnitCount > 5:
                print("Student has 6 or more failed units and does NOT qualify for Honours.\n")
                self.eligibility = "Ineligible"
                sleep(3)
                return


    def calculateHonoursResult(self):
        if self.eligibility != "Ineligible":
            # send results to server calculations
            self.HonourResults = self.proxy.calculateHonoursResults(self.scores, self.id, self.unitScores)
            self.eligibility = self.HonourResults["eligibility"]

            print(f'{self.id}, '
                  f'{self.HonourResults["courseAverage"]}, '
                  f'{self.HonourResults["averageOfBestScores"]}, '
                  f'{self.eligibility}')

        print("")  # Whitespace for pretty presentation
        sleep(3)
        return self


    def showInfo(self):
        print("\n================")
        print("Previous Results")
        print("================")
        print(f"Scores: {self.scores}")
        print(f'Best Scores: {self.HonourResults["bestScores"]}')
        print(f'Course Average: {self.HonourResults["courseAverage"]}')
        print(f'Average of Best Scores: {self.HonourResults["averageOfBestScores"]}')
        print(f"Honours Eligibility: {self.eligibility}")

        print("")  # Whitespace for pretty presentation
        sleep(3)
        return






