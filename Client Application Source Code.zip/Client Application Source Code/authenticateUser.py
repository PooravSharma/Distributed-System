import json
from time import sleep
import os

class AuthenticateUser:
    def __init__(self):
        self.AuthenticUsers = {}
        self.AdminID = "1"
        self.AdminPassword = "admin"
        self.id = ""
        self.clearConsole = lambda: os.system('cls' if os.name in ('nt', 'dos') else 'clear')
        try:
            with open('users.txt', 'r') as file:
                authUsers = json.load(file)
                self.AuthenticUsers = json.loads(authUsers)
        except:
            self.AuthenticUsers = {"10496173":"cat", "10489879":"helpMe"}

    def printMenu(self):
        self.clearConsole()
        print("==============================")
        print("Honour's Pre-Assessment System")
        print("    Authentication Portal")
        print("==============================")
        print("Please enter your Identification Number and Password for Authentication")
        print("To add a new ID enter the Administration credentials")

    def validateID(self):
        id = input("ID: ")
        while id:
            password = input("Password: ")
            if id == self.AdminID and password == self.AdminPassword:
                self.adminControls()
                self.printMenu()
                id = input("ID: ")
            elif id in self.AuthenticUsers and self.AuthenticUsers[id] == password:
                print("User Authenticated.\n")
                sleep(2)
                self.clearConsole()
                break
            else:
                print("Invalid login, cannot authenticate user.")
                print("\nTry again or press enter to Exit the program.")
                id = input("ID: ")
        self.id = id
        return

    def authenticate(self):
        self.printMenu()
        self.validateID()
        return self.id

    def adminControls(self):
        print("\n--------------")
        print("Admin Controls")
        print("--------------")
        print("To add a new ID please type it in below")
        print("To return to the authentication screen, press enter")
        id = input("New ID: ")
        while id:
            while id in self.AuthenticUsers:
                print("\nError, ID already exists\n")
                print("To add a new ID please type it in below")
                print("To return to the authentication screen, press enter")
                id = input("New ID: ")
                if id == "":
                    return
            print("Please Confirm the ID to proceed.")
            confirmID = input("Confirm ID: ")
            if id != confirmID:
                print("\nError, IDs do not match")
                print("Try again or press enter to return to authentication.")
                id = input("New ID: ")
            else:
                password = ""
                while not password:
                    print("Please set the password for new user")
                    password = input("Password: ")
                print("\nID Successfully added, returning to the Authentication Menu\n")
                self.AuthenticUsers[id] = password
                with open('users.txt', 'w') as file:
                    authUsers = json.dumps(self.AuthenticUsers)
                    json.dump(authUsers, file)
                sleep(2)
                return








