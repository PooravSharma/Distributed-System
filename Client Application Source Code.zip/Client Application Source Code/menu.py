import calculateHonours
import xmlrpc.client
class Menu:
    def __init__(self, id, ip = "http://localhost:8000/"):
        self.proxy = xmlrpc.client.ServerProxy(ip)
        self.currentUserInfo = None
        self.userID = id
        self.printMenu()
        self.runMenu()


    def printMenu(self):
        print("==============================")
        print("Honour's Pre-Assessment System")
        print("==============================")
        print(" [1] Calculate New Honours Results [with unit and score]")
        print(" [2] Calculate New Honours Results [with score only]")
        print(" [3] View Previous Results")
        print(" [4] Logout\n")


    def getMenuOption(self):
        option = input("Please select one of the above options: ")
        while option not in ["1", "2", "3", "4"]:
            print("please enter 1 to calculate honours using unit codes,\n"
                  "2 to calculate honours using scores only,\n"
                  "3 to view your previous results,\n"
                  "4 to logout ")
            option = input("Selection : ")
            print("")
        return option

    def runMenu(self):
        option = self.getMenuOption()
        if option == "1":
            print("")
            self.currentUserInfo= calculateHonours.calculateHonoursClient(self.proxy, self.userID, useUnitCodes=True)
        elif option == "2":
            print("")
            self.currentUserInfo = calculateHonours.calculateHonoursClient(self.proxy, self.userID)
        elif option == "3":
            if self.currentUserInfo is not None:
                self.currentUserInfo.showInfo()
            else:
                print("No previous results found, please select option 1 or 2 to add results.\n")
                return self.runMenu()
        elif option == "4":
            print("Logging out...")
            return
        self.printMenu()
        return self.runMenu()

